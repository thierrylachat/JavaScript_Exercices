let message = 'C\'est un message.';
alert(message);