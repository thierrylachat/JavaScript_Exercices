let name = prompt("Quel est votre nom ?");
let age = prompt("Quel est votre âge ?");
let city = prompt("Quelle est la ville dans laquelle vous habitez ?");
alert (`Votre nom est ${name}. Vous avez ${age} ans. Vous habitez ${city}.`);