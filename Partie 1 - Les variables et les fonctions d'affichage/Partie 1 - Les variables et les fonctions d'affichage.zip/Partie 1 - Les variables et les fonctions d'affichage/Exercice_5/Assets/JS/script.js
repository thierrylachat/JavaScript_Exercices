let number1 = prompt("Merci d'indiquer un premier nombre.");
let number2 = prompt("Merci d'indiquer un deuxième nombre.");
let result = parseInt(number1) + parseInt(number2);
console.log(`Le résultat de l'addition de ${number1} avec ${number2} est ${result}.`);