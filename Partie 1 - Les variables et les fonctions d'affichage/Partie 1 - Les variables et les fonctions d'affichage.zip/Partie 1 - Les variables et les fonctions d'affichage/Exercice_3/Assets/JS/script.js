let name = 'Jean';
let age = '30';
let city = 'Paris';
alert (`Bonjour, je m'appelle ${name}, j'ai ${age} ans et j'habite ${city}.`);