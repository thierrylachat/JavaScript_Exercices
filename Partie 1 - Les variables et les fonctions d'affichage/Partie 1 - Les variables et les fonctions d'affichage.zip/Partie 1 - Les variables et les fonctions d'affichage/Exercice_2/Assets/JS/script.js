let firstPart = 'Créer une variable firstPart qui contiendra la première partie d\'une phrase et';
let lastPart = ' une variable lastPart qui contiendra la dernière partie de la même phrase.';
alert(firstPart + lastPart);