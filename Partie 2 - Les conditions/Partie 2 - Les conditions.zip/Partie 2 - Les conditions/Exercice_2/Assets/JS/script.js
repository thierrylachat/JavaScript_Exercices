let age = prompt (`Merci d'indiquer votre âge svp.`);

if (age >= 18) {
    alert (`Vous êtes majeur.`);
} else {
    alert (`Vous êtes mineur.`);
}
