let number = 50;

// Première solution. //

if (number > 21) {
    alert (`Le nombre ${number} est supérieur à 21.`);
}

// Autre solution possible. //

alert ((number > 21) && (`Le nombre ${number} est supérieur à 21.`));